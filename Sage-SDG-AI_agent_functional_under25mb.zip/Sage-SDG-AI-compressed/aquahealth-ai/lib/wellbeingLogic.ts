import { wellbeingDataset } from "../data/wellbeingDataset";

const genericWellbeingResponse = {
  mood_stress_summary: "General Well-being Support",
  reflection_prompt: "What aspect of your well-being would you like to focus on today? Consider your physical health, emotional state, relationships, or sense of purpose.",
  breathing_exercise: "Simple Calming Breath: Breathe in slowly through your nose for 4 counts. Hold for 2 counts. Exhale slowly through your mouth for 6 counts. Repeat 5 times. The longer exhale activates your body's relaxation response.",
  self_care_action: "1) Check your basic needs: Have you eaten well today? Drank enough water? Moved your body? Connected with someone? 2) Take 10 minutes for yourself - walk, stretch, or sit quietly. 3) Write down 3 things you're grateful for. 4) Set one small, achievable goal for today. 5) Remember: small daily actions create lasting well-being.",
  safety_note: "Well-being is holistic - it includes physical health, mental health, relationships, and purpose. If any area feels significantly off, consider speaking with a professional.",
  professional_help_suggestion: "If you're struggling with persistent emotional difficulties, a counselor or therapist can provide personalized support and evidence-based strategies.",
  disclaimer: "I am an AI, not a doctor or therapist. This is not medical advice. For persistent mental health concerns, please consult a qualified professional."
};

const problemSolutions: Record<string, { mood_stress_summary: string; reflection_prompt: string; breathing_exercise: string; self_care_action: string; safety_note: string; professional_help_suggestion: string | null; disclaimer: string }> = {
  "stress": {
    mood_stress_summary: "Stress Management Solutions",
    reflection_prompt: "What are the top 3 sources of your stress? Which ones can you influence or change?",
    breathing_exercise: "Box Breathing: 1) Breathe in for 4 seconds. 2) Hold for 4 seconds. 3) Breathe out for 4 seconds. 4) Hold for 4 seconds. Repeat 4 cycles. This activates your parasympathetic nervous system.",
    self_care_action: "1) Prioritize tasks using the Eisenhower Matrix (urgent/important). 2) Take 10-minute breaks every 2 hours. 3) Exercise for 30 minutes daily. 4) Limit screen time before bed. 5) Talk to someone you trust. 6) Practice saying no to non-essential commitments.",
    safety_note: "Chronic stress weakens your immune system, disrupts sleep, and increases risk of heart disease. Addressing it early prevents long-term health damage.",
    professional_help_suggestion: "If stress persists for more than 2 weeks despite self-care, consider speaking with a counselor or therapist.",
    disclaimer: "I am an AI, not a doctor or therapist. This is not medical advice. For persistent stress, please consult a qualified professional."
  },
  "anxiety": {
    mood_stress_summary: "Anxiety Management & Support",
    reflection_prompt: "What specific situations trigger your anxiety? Can you identify patterns or common themes?",
    breathing_exercise: "4-7-8 Breathing: 1) Inhale through your nose for 4 seconds. 2) Hold for 7 seconds. 3) Exhale slowly through your mouth for 8 seconds. Repeat 3-4 times. This slows your heart rate and calms your mind.",
    self_care_action: "1) Practice the 5-4-3-2-1 grounding technique. 2) Write down your worries - externalizing them reduces their power. 3) Limit caffeine and sugar. 4) Create a calming bedtime routine. 5) Join a support group. 6) Challenge anxious thoughts with evidence-based reasoning.",
    safety_note: "Anxiety is treatable. If it interferes with daily life (work, relationships, sleep), professional help can provide effective strategies like CBT (Cognitive Behavioral Therapy).",
    professional_help_suggestion: "Consider speaking to a mental health professional. CBT is highly effective for anxiety disorders.",
    disclaimer: "I am an AI, not a doctor or therapist. This is not medical advice. For persistent anxiety, please consult a qualified professional."
  },
  "depression": {
    mood_stress_summary: "Depression Awareness & Support Strategies",
    reflection_prompt: "Have you noticed changes in your sleep, appetite, or energy levels? These can be important signs to discuss with someone you trust.",
    breathing_exercise: "Deep Belly Breathing: Place one hand on your chest and one on your belly. Breathe in slowly through your nose, feeling your belly rise. Exhale slowly through pursed lips. Repeat 5-10 times. This helps regulate your nervous system.",
    self_care_action: "1) Maintain a daily routine even when motivation is low. 2) Get 15-30 minutes of sunlight daily. 3) Stay connected with at least one person each day. 4) Do small, manageable activities. 5) Avoid isolating yourself. 6) Set one small achievable goal each day.",
    safety_note: "Depression is a medical condition, not a weakness. It's treatable with therapy, lifestyle changes, and sometimes medication. You don't have to face it alone.",
    professional_help_suggestion: "Please consider speaking to a doctor or mental health professional. Depression is highly treatable with proper support.",
    disclaimer: "I am an AI, not a doctor or therapist. This is not medical advice. For depression symptoms, please consult a qualified professional."
  },
  "sleep": {
    mood_stress_summary: "Sleep Quality Improvement",
    reflection_prompt: "What does your evening routine look like? Are there habits that might be disrupting your sleep?",
    breathing_exercise: "Body Scan Relaxation: Lie down. Starting from your toes, consciously relax each body part moving upward. Breathe deeply throughout. This releases physical tension that prevents sleep.",
    self_care_action: "1) Set a consistent sleep schedule. 2) No screens 30-60 minutes before bed. 3) Keep your room cool, dark, and quiet. 4) Avoid caffeine after 2 PM. 5) Try gentle stretching or reading before bed. 6) If you can't sleep after 20 minutes, get up and do something calm.",
    safety_note: "Poor sleep affects mood, concentration, immune function, and long-term health. Chronic sleep problems may indicate an underlying issue worth discussing with a doctor.",
    professional_help_suggestion: "If sleep problems persist for more than a month, consider seeing a doctor to rule out sleep disorders.",
    disclaimer: "I am an AI, not a doctor. This is not medical advice. For persistent sleep issues, please consult a qualified professional."
  },
  "overwhelm": {
    mood_stress_summary: "Managing Overwhelm & Burnout",
    reflection_prompt: "What tasks or responsibilities are weighing on you most? Can any be delegated, delayed, or simplified?",
    breathing_exercise: "Progressive Muscle Relaxation: Tense each muscle group for 5 seconds, then release. Start from your feet and work up to your face. Breathe deeply throughout. This releases stored tension from overwhelm.",
    self_care_action: "1) Break everything into tiny steps - focus on ONE thing at a time. 2) Say no to new commitments temporarily. 3) Delegate what you can. 4) Set boundaries on work/study hours. 5) Schedule mandatory rest time. 6) Remember: done is better than perfect.",
    safety_note: "Burnout is real and affects physical health. Chronic overwhelm can lead to exhaustion, cynicism, and reduced performance. Recovery requires rest and boundary-setting.",
    professional_help_suggestion: "If burnout symptoms persist (exhaustion, detachment, reduced performance), consider speaking with a counselor.",
    disclaimer: "I am an AI, not a doctor or therapist. This is not medical advice. For persistent overwhelm, please consult a qualified professional."
  },
  "loneliness": {
    mood_stress_summary: "Combating Loneliness & Building Connections",
    reflection_prompt: "What kind of connection are you missing most? Deep conversations, shared activities, or simply regular contact with others?",
    breathing_exercise: "Heart-Centered Breathing: Place your hand on your heart. Breathe slowly and deeply, focusing on feelings of warmth and connection. Imagine reaching out to someone you care about. This activates social engagement systems.",
    self_care_action: "1) Reach out to one person today - a text, call, or visit. 2) Join a group or club aligned with your interests. 3) Volunteer - helping others creates connection. 4) Use community spaces. 5) Consider online communities if in-person isn't accessible. 6) Be patient - meaningful connections take time.",
    safety_note: "Loneliness affects physical health as much as smoking 15 cigarettes a day. Social connection is a fundamental human need, not a luxury.",
    professional_help_suggestion: "If loneliness is contributing to depression or anxiety, a therapist can help develop social skills and connection strategies.",
    disclaimer: "I am an AI, not a doctor or therapist. This is not medical advice. For persistent loneliness affecting mental health, please consult a qualified professional."
  },
  "grief": {
    mood_stress_summary: "Grief Support & Coping Strategies",
    reflection_prompt: "What memories or moments bring you comfort when you think about your loss? It's okay to hold onto those.",
    breathing_exercise: "Gentle Grounding Breath: Sit comfortably. Place both feet flat on the floor. Breathe in slowly for 4 counts, feeling the ground beneath you. Exhale for 6 counts. Repeat 5 times. This helps you feel anchored during emotional waves.",
    self_care_action: "1) Allow yourself to grieve - there is no timeline. 2) Talk about your feelings with someone safe. 3) Create a memorial ritual (light a candle, write a letter). 4) Maintain basic self-care (eat, sleep, move). 5) Join a grief support group. 6) Be gentle with yourself - grief comes in waves.",
    safety_note: "Grief is a natural response to loss. Everyone grieves differently. If grief prevents you from functioning for an extended period, professional support can help you navigate it.",
    professional_help_suggestion: "Consider grief counseling or a support group. Professional guidance can help you process loss in a healthy way.",
    disclaimer: "I am an AI, not a therapist. This is not medical advice. For complicated grief, please consult a qualified professional."
  },
  "addiction": {
    mood_stress_summary: "Addiction Recovery & Support",
    reflection_prompt: "What triggers your urge to use? Can you identify patterns in when and why you reach for the substance or behavior?",
    breathing_exercise: "Urge Surfing Breath: When an urge hits, don't fight it. Breathe slowly and observe the urge like a wave - it will rise, peak, and fall. Most urges last only 20-30 minutes. Breathe through it.",
    self_care_action: "1) Identify and avoid your triggers. 2) Replace the habit with a healthier alternative (exercise, calling a friend). 3) Build a support network of people who understand. 4) Set small, achievable sobriety goals. 5) Practice self-compassion - relapse is part of recovery for many. 6) Celebrate milestones, no matter how small.",
    safety_note: "Addiction is a medical condition, not a moral failing. Withdrawal from some substances can be dangerous - medical supervision may be needed. You deserve support and recovery is possible.",
    professional_help_suggestion: "Please reach out to an addiction counselor, support group (AA, NA, SMART Recovery), or medical professional. Recovery is much more achievable with support.",
    disclaimer: "I am an AI, not a medical professional. For addiction and withdrawal, please consult qualified healthcare providers."
  },
  "relationship": {
    mood_stress_summary: "Relationship Challenges & Communication",
    reflection_prompt: "What do you need most from this relationship right now? Have you communicated this clearly to the other person?",
    breathing_exercise: "Pause Breath: Before responding in conflict, take 3 deep breaths. This creates space between trigger and response, allowing you to choose your words rather than react impulsively.",
    self_care_action: "1) Practice active listening - hear to understand, not to respond. 2) Use 'I' statements instead of blame ('I feel...' not 'You always...'). 3) Set healthy boundaries. 4) Take breaks during heated arguments. 5) Seek couples/family counseling if needed. 6) Focus on what you can control - your own behavior and responses.",
    safety_note: "If a relationship involves abuse (physical, emotional, verbal), your safety comes first. Reach out to a domestic violence hotline or trusted person immediately.",
    professional_help_suggestion: "Relationship counseling can provide tools for communication, conflict resolution, and rebuilding trust.",
    disclaimer: "I am an AI, not a therapist. This is not medical advice. For relationship difficulties, consider speaking with a counselor."
  },
  "workplace": {
    mood_stress_summary: "Workplace Stress & Conflict Resolution",
    reflection_prompt: "What specific aspects of your work environment are causing the most distress? Are they within your control to change?",
    breathing_exercise: "Reset Breath: Step away from your desk if possible. Take 5 deep breaths, focusing on relaxing your shoulders and jaw. This resets your nervous system before returning to stressful situations.",
    self_care_action: "1) Document specific issues (dates, incidents, impacts). 2) Communicate concerns professionally to your supervisor or HR. 3) Set clear work-life boundaries (no emails after hours). 4) Build supportive relationships with colleagues. 5) Explore internal transfer options if needed. 6) Know your rights regarding workplace harassment and discrimination.",
    safety_note: "Workplace bullying, harassment, and discrimination are not acceptable. Document everything and know your legal rights. Your mental health matters more than any job.",
    professional_help_suggestion: "If workplace issues are significantly affecting your mental health, consider speaking with an HR professional, union representative, or employment counselor.",
    disclaimer: "I am an AI, not a legal or career advisor. For workplace issues, consult HR professionals or employment resources."
  },
  "financial": {
    mood_stress_summary: "Financial Stress & Money Management",
    reflection_prompt: "What is your biggest financial worry right now? Can you break it down into smaller, manageable steps?",
    breathing_exercise: "Calming Breath: Financial stress triggers fight-or-flight. Slow your breathing: inhale for 4, hold for 2, exhale for 6. The longer exhale activates your relaxation response.",
    self_care_action: "1) Create a simple budget - track income and expenses for one month. 2) Build a small emergency fund (even $5/week helps). 3) Prioritize essential expenses (food, housing, healthcare). 4) Seek free financial counseling services. 5) Avoid taking on new debt. 6) Explore community resources (food banks, assistance programs). 7) Remember: financial stress is temporary and solvable.",
    safety_note: "Financial stress is one of the leading causes of anxiety and depression. You are not alone - many people face money challenges. Seeking help is a sign of strength, not weakness.",
    professional_help_suggestion: "Consider free financial counseling services, community assistance programs, or a financial advisor for personalized guidance.",
    disclaimer: "I am an AI, not a financial advisor. For significant financial decisions, consult qualified financial professionals."
  },
  "self-esteem": {
    mood_stress_summary: "Building Self-Esteem & Self-Worth",
    reflection_prompt: "What is one thing you've accomplished recently, no matter how small? You deserve to acknowledge your own efforts.",
    breathing_exercise: "Self-Compassion Breath: Place your hand on your heart. Breathe in while thinking 'I am enough.' Breathe out while releasing self-judgment. Repeat 5 times. This builds self-compassion neural pathways.",
    self_care_action: "1) Challenge negative self-talk - would you say these things to a friend? 2) Write down 3 things you appreciate about yourself daily. 3) Surround yourself with supportive people. 4) Set and celebrate small goals. 5) Practice self-care as a non-negotiable. 6) Limit social media comparison. 7) Remember: your worth is not determined by productivity or others' opinions.",
    safety_note: "Low self-esteem can contribute to depression, anxiety, and unhealthy relationships. Building self-worth is a practice that takes time and patience.",
    professional_help_suggestion: "Therapy (especially CBT) is very effective for building self-esteem and challenging negative thought patterns.",
    disclaimer: "I am an AI, not a therapist. This is not medical advice. For persistent self-esteem issues, please consult a qualified professional."
  },
  "anger": {
    mood_stress_summary: "Anger Management & Emotional Regulation",
    reflection_prompt: "What triggered your anger? Is there an underlying need or boundary that wasn't respected?",
    breathing_exercise: "Cool-Down Breath: Breathe in deeply for 4 counts through your nose. Hold for 4 counts. Exhale slowly for 8 counts through pursed lips (like blowing out a candle). Repeat until you feel your body relax. The extended exhale signals safety to your nervous system.",
    self_care_action: "1) Pause before reacting - count to 10 or leave the situation temporarily. 2) Identify the real trigger (often it's not the surface issue). 3) Express your feelings using 'I' statements. 4) Channel anger into constructive action (exercise, problem-solving). 5) Practice forgiveness - for others and yourself. 6) Learn to recognize early warning signs of anger buildup.",
    safety_note: "Anger is a normal emotion, but uncontrolled anger can damage relationships and health. If anger leads to aggression or violence, professional help is important.",
    professional_help_suggestion: "If anger is affecting your relationships or daily life, anger management counseling can provide effective coping strategies.",
    disclaimer: "I am an AI, not a therapist. This is not medical advice. For anger management difficulties, consider speaking with a counselor."
  },
  "trauma": {
    mood_stress_summary: "Trauma Recovery & Healing Support",
    reflection_prompt: "What helps you feel safe right now? It's okay to focus only on what you need in this moment.",
    breathing_exercise: "Grounding Breath: Sit with both feet on the floor. Breathe in for 4 counts, noticing 5 things you can see. Hold for 4 counts, noticing 4 things you can touch. Exhale for 6 counts, noticing 3 things you can hear. This 5-4-3 technique grounds you in the present moment.",
    self_care_action: "1) Prioritize safety and stability first. 2) Connect with trusted people who make you feel safe. 3) Maintain routines when possible - they provide predictability. 4) Practice self-compassion - healing is not linear. 5) Avoid using substances to numb feelings. 6) Engage in gentle physical activity (walking, stretching, yoga). 7) Consider journaling when you feel ready.",
    safety_note: "Trauma affects the brain and body. Healing takes time and often requires professional support. You are not broken - you are responding to difficult experiences. Recovery is possible.",
    professional_help_suggestion: "Trauma-informed therapy (such as EMDR, somatic therapy, or trauma-focused CBT) is highly effective. Please consider reaching out to a mental health professional trained in trauma.",
    disclaimer: "I am an AI, not a therapist. This is not medical advice. For trauma recovery, please consult a qualified trauma-informed professional."
  },
  "parenting": {
    mood_stress_summary: "Parenting Stress & Family Well-being",
    reflection_prompt: "What aspect of parenting feels most challenging right now? Remember: asking for help is a sign of strength, not failure.",
    breathing_exercise: "Parent Pause Breath: When feeling overwhelmed, step away if safe to do so. Take 5 deep breaths: in for 4, out for 6. This resets your nervous system so you can respond to your child rather than react.",
    self_care_action: "1) You cannot pour from an empty cup - prioritize your own well-being. 2) Build a support network (other parents, family, community groups). 3) Set realistic expectations - there is no 'perfect' parent. 4) Take breaks when possible, even 10 minutes helps. 5) Practice self-compassion when you make mistakes (you will, and that's okay). 6) Seek parenting resources and education. 7) Remember: your mental health directly impacts your children's well-being.",
    safety_note: "Parenting stress is real and valid. If you ever feel like you might harm your child or yourself, seek immediate help. Postpartum depression and parental burnout are treatable conditions.",
    professional_help_suggestion: "Consider parenting support groups, family counseling, or individual therapy. Postpartum depression requires professional treatment.",
    disclaimer: "I am an AI, not a therapist. This is not medical advice. For parenting stress or postpartum concerns, please consult a qualified professional."
  },
  "academic stress": {
    mood_stress_summary: "Academic Stress & Study Well-being",
    reflection_prompt: "What is causing the most academic pressure right now? Is it expectations (yours or others'), workload, or fear of failure?",
    breathing_exercise: "Focus Breath: Before studying or taking exams, breathe in for 4 counts, hold for 4, exhale for 4, hold for 4 (Box Breathing). This improves focus and reduces test anxiety. Repeat 4 cycles.",
    self_care_action: "1) Break study material into manageable chunks with breaks (Pomodoro technique: 25 min study, 5 min break). 2) Get 7-9 hours of sleep - it's critical for memory consolidation. 3) Exercise regularly - it improves cognitive function and reduces stress. 4) Eat nutritious meals and stay hydrated. 5) Form study groups for support. 6) Challenge perfectionism - 'done' is better than 'perfect.' 7) Remember: your worth is not defined by grades.",
    safety_note: "Academic stress can lead to burnout, anxiety, and depression. If you're experiencing persistent academic distress, reach out to school counselors or mental health services.",
    professional_help_suggestion: "Many schools offer free counseling services. Academic stress, test anxiety, and burnout are common and treatable.",
    disclaimer: "I am an AI, not a counselor. This is not medical advice. For academic stress affecting your well-being, consult a school counselor or mental health professional."
  },
  "social anxiety": {
    mood_stress_summary: "Social Anxiety & Connection Support",
    reflection_prompt: "What specific social situations make you most anxious? What is the worst thing you fear will happen, and how likely is it really?",
    breathing_exercise: "Pre-Social Calm Breath: Before entering a social situation, breathe in for 4 counts through your nose, exhale for 8 counts through your mouth. Repeat 5 times. The longer exhale activates your parasympathetic nervous system, reducing anxiety.",
    self_care_action: "1) Start small - practice social interactions in low-pressure settings. 2) Prepare conversation topics in advance. 3) Focus on the other person (ask questions, listen actively) rather than on yourself. 4) Challenge negative thoughts ('Everyone will judge me') with evidence. 5) Practice self-compassion after social interactions. 6) Gradually increase social exposure. 7) Remember: most people are focused on themselves, not judging you.",
    safety_note: "Social anxiety is one of the most common anxiety disorders. It's highly treatable with the right support. Avoiding all social situations can make anxiety worse over time.",
    professional_help_suggestion: "CBT (Cognitive Behavioral Therapy) is very effective for social anxiety. Consider speaking with a therapist who specializes in anxiety disorders.",
    disclaimer: "I am an AI, not a therapist. This is not medical advice. For social anxiety affecting your daily life, please consult a qualified professional."
  }
};

function findBestMatch(message: string) {
  const lower = message.toLowerCase();
  
  const keywordMap: Record<string, string[]> = {
    "stress": ["stress", "stressed", "pressure", "tension", "workload", "busy", "overworked"],
    "anxiety": ["anxious", "anxiety", "worried", "worry", "nervous", "panic", "fear", "scared"],
    "depression": ["depressed", "depression", "sad", "hopeless", "empty", "numb", "no motivation", "lost interest"],
    "sleep": ["sleep", "insomnia", "can't sleep", "tired", "fatigue", "exhausted", "rest", "nightmare"],
    "overwhelm": ["overwhelm", "too much", "burnout", "burnt out", "can't cope", "breaking point", "drowning"],
    "loneliness": ["lonely", "alone", "isolated", "no friends", "nobody", "disconnected", "no one cares"],
    "grief": ["grief", "grieving", "loss", "death", "lost someone", "mourning", "miss them"],
    "addiction": ["addiction", "addicted", "substance", "alcohol", "drug", "smoking", "gambling", "can't stop"],
    "relationship": ["relationship", "partner", "spouse", "marriage", "friend", "family", "conflict", "argument", "breakup"],
    "workplace": ["work", "job", "boss", "colleague", "coworker", "bullying", "harassment", "discrimination", "career"],
    "financial": ["money", "financial", "debt", "broke", "poor", "bill", "budget", "can't afford", "bankrupt"],
    "self-esteem": ["self-esteem", "confidence", "worthless", "ugly", "not good enough", "hate myself", "insecure"],
    "anger": ["anger", "angry", "rage", "frustrated", "irritated", "furious", "mad"],
    "trauma": ["trauma", "traumatic", "abuse", "assault", "ptsd", "flashback", "nightmare"],
    "parenting": ["parenting", "parent", "child", "baby", "mother", "father", "postpartum"],
    "academic stress": ["academic", "study", "exam", "test", "school stress", "grades", "university"],
    "social anxiety": ["social anxiety", "social fear", "afraid of people", "crowd", "public speaking"]
  };
  
  for (const [key, keywords] of Object.entries(keywordMap)) {
    if (keywords.some(kw => lower.includes(kw))) {
      return problemSolutions[key];
    }
  }
  
  return genericWellbeingResponse;
}

export function handleWellbeingQuery(message: string) {
  const lowerMessage = message.toLowerCase();
  
  const crisisKeywords = ['suicide', 'kill myself', 'end my life', 'want to die', 'hurt myself', 'self-harm', 'self harm', 'cutting', 'don\'t want to live', 'no reason to live', 'better off dead'];
  const isCrisis = crisisKeywords.some(keyword => lowerMessage.includes(keyword));

  if (isCrisis) {
    return {
      mood_stress_summary: "CRISIS SUPPORT - Your Safety Matters",
      reflection_prompt: "Please pause and focus on your immediate safety. You are not alone.",
      breathing_exercise: "Take one slow, deep breath in... and slowly let it out. Focus only on this moment.",
      self_care_action: "Please reach out to someone you trust right now - a friend, family member, or crisis hotline. Your life matters and help is available.",
      safety_note: "CRISIS ALERT: If you are in immediate danger, please call your local emergency number (such as 911) or go to the nearest emergency room. You are not alone - people want to help you.",
      professional_help_suggestion: "Please contact a crisis helpline immediately: In the US, call or text 988 (Suicide & Crisis Lifeline). In the UK, call 111 or Samaritans at 116 123. In India, call Kiran at 1800-599-0019. International resources: findahelpline.com or befrienders.org",
      disclaimer: "I am an AI, not a crisis counselor. I cannot provide emergency help. Please contact professional crisis services immediately."
    };
  }

  const isProblemQuery = lowerMessage.includes("problem") || lowerMessage.includes("solve") || 
    lowerMessage.includes("how to") || lowerMessage.includes("deal with") || lowerMessage.includes("handle") ||
    lowerMessage.includes("manage") || lowerMessage.includes("help with") || lowerMessage.includes("improve") ||
    lowerMessage.includes("cope") || lowerMessage.includes("stop") || lowerMessage.includes("overcome");

  if (isProblemQuery) {
    return findBestMatch(message);
  }

  let matchedRecord = wellbeingDataset[3];

  for (const record of wellbeingDataset) {
    if (lowerMessage.includes(record.mood_state.toLowerCase())) {
      matchedRecord = record;
      break;
    }
  }

  return {
    mood_stress_summary: `${matchedRecord.mood_state} (Stress: ${matchedRecord.stress_level})`,
    reflection_prompt: matchedRecord.reflection_prompt,
    breathing_exercise: matchedRecord.breathing_exercise,
    self_care_action: matchedRecord.self_care_action,
    safety_note: matchedRecord.safety_note,
    professional_help_suggestion: matchedRecord.professional_help_trigger ? "Consider speaking to a mental health professional." : null,
    disclaimer: "I am an AI, not a doctor or therapist. This is not medical advice."
  };
}
