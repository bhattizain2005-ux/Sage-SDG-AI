import { waterDataset } from "../data/waterDataset";

const genericWaterResponse = {
  issue_summary: "General Water & Sanitation Guidance (SDG 6)",
  possible_cause: "Water and sanitation challenges can stem from infrastructure gaps, environmental factors, contamination, or resource management issues.",
  risk_level: "Medium",
  immediate_safety_steps: "1) Always prioritize safe drinking water - boil, filter, or use verified safe sources. 2) Practice proper hygiene - wash hands with soap before eating and after using the toilet. 3) Store water in clean, covered containers. 4) Keep sanitation areas clean and waste properly disposed. 5) Report persistent water issues to local authorities. 6) Educate your community about water safety practices.",
  health_risk_awareness: "Unsafe water and poor sanitation cause 485,000 diarrheal deaths annually. Clean water, proper sanitation, and good hygiene (WASH) are fundamental to public health. Every $1 invested in water and sanitation returns $4-12 in health and economic benefits.",
  complaint_report_suggestion: "Priority: Normal. Contact your local water authority, health department, or community leaders about water and sanitation concerns. Document issues with photos and descriptions. Partner with NGOs working on water access (Water.org, charity: water, UNICEF) for community-level solutions.",
  disclaimer: "I am an AI, not a water quality expert or environmental scientist. For specific water testing and infrastructure advice, consult local health authorities or water professionals."
};

const problemSolutions: Record<string, { issue_summary: string; possible_cause: string; risk_level: string; immediate_safety_steps: string; health_risk_awareness: string; complaint_report_suggestion: string; disclaimer: string }> = {
  "clean water access": {
    issue_summary: "Ensuring Clean Water Access for Communities",
    possible_cause: "Lack of infrastructure, contaminated sources, poverty, poor water management, or environmental degradation.",
    risk_level: "High",
    immediate_safety_steps: "1) Map all water sources in your community and test quality. 2) Implement point-of-use treatment (boiling, filtration, chlorination). 3) Build rainwater harvesting systems. 4) Protect water sources from contamination (fencing, waste management). 5) Establish community water committees for maintenance. 6) Advocate for government investment in water infrastructure. 7) Partner with NGOs (Water.org, charity: water, UNICEF) for funding.",
    health_risk_awareness: "Unsafe water causes 485,000 diarrheal deaths annually. Children under 5 are most vulnerable. Clean water access reduces child mortality by 50% and improves school attendance by 25%. Every $1 invested in water returns $4-12 in health and economic benefits.",
    complaint_report_suggestion: "Priority: Critical. Contact local government, NGOs, or UNICEF for community water projects. Document water quality issues with photos and health data to strengthen your case. Mobilize community support for collective action.",
    disclaimer: "I am an AI, not a water quality expert. For water testing and infrastructure advice, consult local health authorities or water professionals."
  },
  "water contamination": {
    issue_summary: "Water Contamination Prevention & Response",
    possible_cause: "Industrial discharge, agricultural runoff (pesticides, fertilizers), sewage leakage, mining waste, or inadequate water treatment.",
    risk_level: "Emergency",
    immediate_safety_steps: "1) STOP using the suspected water source immediately. 2) Use bottled or boiled water for drinking and cooking. 3) Do not let children or pets near contaminated water. 4) Document the contamination (photos, location, symptoms). 5) Report to environmental health authorities immediately. 6) If people are sick, seek medical attention and inform doctors about the suspected contamination. 7) Alert neighbors to avoid the water source.",
    health_risk_awareness: "Contaminated water can contain bacteria (E. coli, cholera), viruses (hepatitis, polio), parasites (giardia), chemicals (lead, arsenic, pesticides), or industrial toxins. Effects range from immediate gastrointestinal illness to long-term organ damage and cancer.",
    complaint_report_suggestion: "Priority: Critical. File a report with your local environmental protection agency, health department, and water utility. Include location, description, affected people, and any symptoms. Request water testing.",
    disclaimer: "I am an AI, not a doctor or environmental scientist. For contamination incidents, contact health authorities and environmental agencies immediately."
  },
  "waterborne disease": {
    issue_summary: "Waterborne Disease Prevention & Treatment",
    possible_cause: "Consumption of water contaminated with pathogens (bacteria, viruses, parasites) from human or animal waste.",
    risk_level: "Emergency",
    immediate_safety_steps: "1) Seek medical attention for anyone with symptoms (diarrhea, vomiting, fever, dehydration). 2) Use Oral Rehydration Solution (ORS) - mix 6 tsp sugar + 1/2 tsp salt in 1 liter clean water. 3) Stop using the suspected water source. 4) Boil all water for 1-3 minutes before use. 5) Practice strict handwashing with soap. 6) Isolate contaminated water sources. 7) Ensure adequate fluid intake to prevent dehydration.",
    health_risk_awareness: "Waterborne diseases kill 485,000 people yearly. Cholera, typhoid, dysentery, and hepatitis A are common. Children under 5 account for 90% of deaths. Dehydration is the primary cause of death - rehydration saves lives.",
    complaint_report_suggestion: "Priority: Critical. Report to local health department immediately. Request epidemiological investigation. Community-wide outbreaks require coordinated response from health authorities.",
    disclaimer: "I am an AI, not a doctor. For waterborne disease symptoms, seek medical attention immediately. Do not delay treatment."
  },
  "water filtration": {
    issue_summary: "Water Filtration & Purification Solutions",
    possible_cause: "Need for safe drinking water where treated water is unavailable or unreliable.",
    risk_level: "Medium",
    immediate_safety_steps: "1) Boiling: Bring water to rolling boil for 1-3 minutes (kills pathogens). 2) Cloth filtration: Use clean cloth to remove large particles. 3) Sand filtration: Build biosand filter for household use. 4) Chlorination: Add 2 drops of unscented bleach per liter, wait 30 minutes. 5) Solar disinfection (SODIS): Fill clear bottles, expose to sunlight for 6 hours. 6) Commercial filters: Use certified filters (ceramic, activated carbon, UV).",
    health_risk_awareness: "Proper water treatment removes 99.9% of pathogens. Boiling is the most reliable household method. Filtration removes particles but may not kill all pathogens - combine methods for best results.",
    complaint_report_suggestion: "Priority: Normal. For community-level solutions, contact NGOs specializing in water treatment (e.g., Water Mission, Living Water International). For household solutions, research locally available filter options.",
    disclaimer: "I am an AI, not a water treatment specialist. For large-scale water treatment, consult professionals."
  },
  "water conservation": {
    issue_summary: "Water Conservation & Sustainable Management",
    possible_cause: "Water scarcity due to overuse, climate change, population growth, or inefficient water management.",
    risk_level: "Medium",
    immediate_safety_steps: "1) Fix leaks immediately (a dripping tap wastes 20 liters/day). 2) Install water-efficient fixtures (low-flow showerheads, dual-flush toilets). 3) Collect rainwater for gardening and cleaning. 4) Reuse greywater (from washing) for irrigation. 5) Water plants early morning or evening to reduce evaporation. 6) Educate community about water-saving practices. 7) Advocate for water conservation policies.",
    health_risk_awareness: "Water scarcity affects 2 billion people. Conserving water ensures sustainable supply, reduces energy used for water treatment, and protects ecosystems. Every liter saved contributes to community resilience.",
    complaint_report_suggestion: "Priority: Normal. Advocate for water conservation policies at community level. Support water infrastructure improvements. Join or start a local water conservation group.",
    disclaimer: "I am an AI, not a water management expert. For large-scale conservation planning, consult water resource professionals."
  },
  "sanitation": {
    issue_summary: "Sanitation Infrastructure & Hygiene Solutions",
    possible_cause: "Lack of toilets, inadequate sewage systems, open defecation, or poor waste management contaminating water sources.",
    risk_level: "High",
    immediate_safety_steps: "1) Build or access proper toilet facilities. 2) Practice handwashing with soap after using toilet and before eating. 3) Keep human waste away from water sources (minimum 30 meters). 4) Manage solid waste properly (composting, recycling, safe disposal). 5) Clean and disinfect water storage containers regularly. 6) Educate community about sanitation-health connections. 7) Partner with organizations (WaterAid, UNICEF) for infrastructure funding.",
    health_risk_awareness: "Poor sanitation causes 432,000 diarrheal deaths annually. Fecal contamination of water spreads cholera, typhoid, hepatitis, and intestinal worms. Every $1 invested in sanitation returns $5.50 in reduced healthcare costs and increased productivity.",
    complaint_report_suggestion: "Priority: Urgent. Contact local government for sanitation infrastructure. Partner with organizations like WaterAid, UNICEF, or WSSCC for community sanitation programs.",
    disclaimer: "I am an AI, not a sanitation engineer. For infrastructure planning, consult public health and engineering professionals."
  },
  "flood": {
    issue_summary: "Flood Management & Water Safety",
    possible_cause: "Heavy rainfall, river overflow, poor drainage, deforestation, or inadequate flood infrastructure.",
    risk_level: "Emergency",
    immediate_safety_steps: "1) Move to higher ground immediately. 2) Do NOT walk or drive through flood water (6 inches can knock you down). 3) Assume all flood water is contaminated. 4) Turn off electricity if water enters your home. 5) After flooding: disinfect wells, throw away food that contacted flood water, clean and dry all surfaces to prevent mold. 6) Follow local authority guidance before returning home.",
    health_risk_awareness: "Flood water carries sewage, chemicals, and debris. Contact can cause skin infections, gastrointestinal illness, and respiratory problems from mold growth. Standing water breeds mosquitoes that spread diseases like malaria and dengue.",
    complaint_report_suggestion: "Priority: Critical. Report flooding to emergency services and local government. Request flood risk assessment and infrastructure improvements. Advocate for early warning systems.",
    disclaimer: "I am an AI, not an emergency services professional. In flood emergencies, follow official evacuation orders and emergency guidance."
  },
  "drought": {
    issue_summary: "Drought Response & Water Rationing",
    possible_cause: "Prolonged lack of rainfall, climate change, over-extraction of groundwater, or poor water resource management.",
    risk_level: "High",
    immediate_safety_steps: "1) Implement strict water rationing - prioritize drinking, cooking, and hygiene. 2) Collect and store any available rainwater. 3) Reduce water waste (fix leaks, reuse greywater). 4) Plant drought-resistant crops. 5) Protect remaining water sources from contamination. 6) Support community water-sharing programs. 7) Advocate for long-term water security planning and infrastructure investment.",
    health_risk_awareness: "Drought reduces water availability for drinking, hygiene, and agriculture. This increases waterborne disease risk (concentrated contaminants), malnutrition (crop failure), and conflict over resources. Vulnerable populations (children, elderly) are most affected.",
    complaint_report_suggestion: "Priority: Urgent. Contact local water authorities for drought relief programs. Advocate for drought-resistant infrastructure and community water storage solutions.",
    disclaimer: "I am an AI, not a water resource expert. For drought management, consult water authorities and agricultural extension services."
  },
  "industrial pollution": {
    issue_summary: "Industrial Water Pollution Prevention",
    possible_cause: "Factory discharge, mining operations, chemical spills, oil leaks, or inadequate industrial waste treatment.",
    risk_level: "Emergency",
    immediate_safety_steps: "1) STOP using water from affected sources immediately. 2) Document pollution (photos, water samples, location). 3) Report to environmental protection agency immediately. 4) Alert affected community members. 5) Seek medical attention if exposed. 6) Demand industrial accountability and proper waste treatment. 7) Support legal action against polluters if necessary.",
    health_risk_awareness: "Industrial pollution introduces heavy metals (lead, mercury, arsenic), chemicals, and toxins into water. These cause cancer, organ damage, neurological disorders, and birth defects. Effects can be immediate or develop over years of exposure.",
    complaint_report_suggestion: "Priority: Critical. File complaints with environmental agencies, health departments, and legal authorities. Document everything. Partner with environmental NGOs for advocacy and legal support.",
    disclaimer: "I am an AI, not an environmental lawyer or scientist. For industrial pollution, contact environmental agencies and legal professionals immediately."
  },
  "agricultural water": {
    issue_summary: "Agricultural Water Management & Irrigation",
    possible_cause: "Inefficient irrigation, pesticide/fertilizer runoff, soil erosion, or over-extraction of groundwater for farming.",
    risk_level: "Medium",
    immediate_safety_steps: "1) Implement drip irrigation to reduce water waste by 30-50%. 2) Use organic fertilizers and integrated pest management. 3) Create buffer zones between fields and water sources. 4) Practice crop rotation to maintain soil health. 5) Collect rainwater for irrigation. 6) Monitor groundwater levels to prevent over-extraction. 7) Train farmers in sustainable water management practices.",
    health_risk_awareness: "Agricultural runoff carries pesticides, fertilizers, and sediment into water sources. This causes algal blooms, oxygen depletion, and contamination of drinking water. Nitrates in water are especially dangerous for infants (blue baby syndrome).",
    complaint_report_suggestion: "Priority: Normal. Work with agricultural extension services to implement sustainable practices. Advocate for regulations on agricultural runoff and water extraction.",
    disclaimer: "I am an AI, not an agricultural expert. For farming water management, consult agricultural extension services."
  },
  "plastic pollution": {
    issue_summary: "Plastic Pollution in Water Systems",
    possible_cause: "Single-use plastic waste, inadequate waste management, littering, or industrial plastic production.",
    risk_level: "High",
    immediate_safety_steps: "1) Reduce single-use plastic consumption. 2) Properly dispose of and recycle plastic waste. 3) Participate in or organize waterway cleanups. 4) Support bans on single-use plastics. 5) Use reusable alternatives (bags, bottles, containers). 6) Educate community about plastic pollution impacts. 7) Advocate for extended producer responsibility policies.",
    health_risk_awareness: "Plastic pollution breaks down into microplastics that enter the food chain and drinking water. Microplastics have been found in human blood, lungs, and placenta. They carry toxic chemicals and disrupt endocrine systems. Marine ecosystems are devastated by plastic waste.",
    complaint_report_suggestion: "Priority: Urgent. Advocate for plastic reduction policies, improved waste management infrastructure, and corporate responsibility. Support organizations working on ocean and waterway cleanup.",
    disclaimer: "I am an AI, not an environmental scientist. For plastic pollution solutions, consult environmental organizations and waste management experts."
  },
  "water rights": {
    issue_summary: "Water Rights & Equitable Access",
    possible_cause: "Privatization, unequal distribution, discrimination, lack of legal protection, or corporate control of water resources.",
    risk_level: "High",
    immediate_safety_steps: "1) Know your legal rights to water access. 2) Document water access inequalities in your community. 3) Organize community advocacy for equitable water distribution. 4) Contact human rights organizations (UN, Amnesty International). 5) Support legal frameworks recognizing water as a human right. 6) Build coalitions with affected communities. 7) Use media to raise awareness about water injustice.",
    health_risk_awareness: "When water access is unequal, marginalized communities suffer disproportionately - higher disease rates, reduced education (children fetching water), and economic disadvantage. Water is a fundamental human right recognized by the UN since 2010.",
    complaint_report_suggestion: "Priority: Critical. File complaints with human rights bodies, water regulators, and local government. Partner with legal aid organizations and water rights NGOs for advocacy.",
    disclaimer: "I am an AI, not a legal expert. For water rights issues, consult legal professionals and human rights organizations."
  },
  "water infrastructure": {
    issue_summary: "Water Infrastructure Development & Maintenance",
    possible_cause: "Aging pipelines, inadequate treatment facilities, lack of investment, poor maintenance, or rapid urbanization outpacing infrastructure.",
    risk_level: "High",
    immediate_safety_steps: "1) Report leaks, pipe breaks, and infrastructure failures immediately. 2) Use point-of-use water treatment while infrastructure is compromised. 3) Store emergency water supply (3-day minimum). 4) Support community water infrastructure advocacy. 5) Participate in water infrastructure planning meetings. 6) Document infrastructure failures with photos and dates.",
    health_risk_awareness: "Aging or inadequate water infrastructure leads to contamination, water loss (up to 30% in some systems), and service interruptions. Infrastructure investment prevents disease outbreaks and ensures reliable access.",
    complaint_report_suggestion: "Priority: Urgent. Contact your water utility, local government, and public works department. Request infrastructure assessments and investment plans. Advocate for water infrastructure funding.",
    disclaimer: "I am an AI, not a civil engineer. For water infrastructure planning, consult water engineering professionals."
  },
  "water testing": {
    issue_summary: "Water Quality Testing & Monitoring",
    possible_cause: "Need to verify water safety due to appearance, taste, odor changes, or health concerns.",
    risk_level: "Medium",
    immediate_safety_steps: "1) Use home water test kits for basic parameters (pH, chlorine, bacteria). 2) Send samples to certified laboratories for comprehensive testing. 3) Test for specific contaminants based on local risks (lead, arsenic, nitrates). 4) Monitor water quality regularly, not just when problems appear. 5) Share results with community and authorities. 6) Take immediate action if tests show contamination.",
    health_risk_awareness: "Regular water testing is the only way to confirm water safety. Many contaminants (lead, arsenic, nitrates) are invisible and tasteless. Testing prevents long-term health effects from chronic exposure.",
    complaint_report_suggestion: "Priority: Normal. Contact local health departments for free or low-cost water testing programs. Partner with universities or NGOs that offer community water testing.",
    disclaimer: "I am an AI, not a water testing laboratory. For accurate water quality assessment, use certified testing facilities."
  },
  "rainwater harvesting": {
    issue_summary: "Rainwater Harvesting & Storage Solutions",
    possible_cause: "Limited access to piped water, water scarcity, high water costs, or desire for water independence.",
    risk_level: "Low",
    immediate_safety_steps: "1) Install gutters and downspouts to direct rainwater to storage. 2) Use food-grade storage tanks with covers to prevent contamination. 3) Install first-flush diverters to exclude initial dirty runoff. 4) Treat harvested rainwater before drinking (filtration + disinfection). 5) Clean gutters and tanks regularly. 6) Check local regulations about rainwater collection.",
    health_risk_awareness: "Rainwater is generally clean but can be contaminated by roof materials, bird droppings, and air pollution. Proper collection, storage, and treatment make it safe for drinking and household use.",
    complaint_report_suggestion: "Priority: Normal. Research local rainwater harvesting regulations and incentives. Connect with communities practicing rainwater harvesting for best practices.",
    disclaimer: "I am an AI, not a rainwater harvesting specialist. For system design, consult water harvesting experts or local extension services."
  },
  "groundwater": {
    issue_summary: "Groundwater Protection & Sustainable Use",
    possible_cause: "Over-extraction, contamination from agriculture/industry, saltwater intrusion, or lack of recharge.",
    risk_level: "High",
    immediate_safety_steps: "1) Monitor groundwater levels in your area. 2) Reduce water waste to decrease extraction pressure. 3) Protect recharge areas from development and contamination. 4) Test private wells regularly for contaminants. 5) Support policies limiting over-extraction. 6) Promote artificial recharge methods (recharge pits, percolation tanks).",
    health_risk_awareness: "Groundwater provides drinking water for 2.5 billion people. Over-extraction causes wells to dry up, land subsidence, and saltwater intrusion. Contamination from agriculture and industry can render groundwater unsafe for decades.",
    complaint_report_suggestion: "Priority: Urgent. Report groundwater contamination to environmental agencies. Advocate for sustainable groundwater management policies and monitoring programs.",
    disclaimer: "I am an AI, not a hydrogeologist. For groundwater assessment and management, consult water resource professionals."
  },
  "waterborne disease outbreak": {
    issue_summary: "Waterborne Disease Outbreak Response",
    possible_cause: "Contaminated water supply, sewage contamination, flooding, or failure of water treatment systems.",
    risk_level: "Emergency",
    immediate_safety_steps: "1) STOP using tap water for drinking, cooking, or brushing teeth. 2) Use bottled water or boil water for at least 1 minute. 3) Follow boil water advisories from health authorities. 4) Seek medical attention for anyone with symptoms (diarrhea, vomiting, fever). 5) Practice strict hand hygiene with soap and safe water. 6) Disinfect surfaces that may have contacted contaminated water. 7) Do not prepare food for others if you have symptoms.",
    health_risk_awareness: "Waterborne disease outbreaks can affect thousands. Common pathogens include E. coli, cholera, cryptosporidium, and norovirus. Children, elderly, and immunocompromised individuals are at highest risk. Rapid response saves lives.",
    complaint_report_suggestion: "Priority: Critical. Report to health department immediately. Request outbreak investigation. Community-wide response requires coordination between health authorities, water utilities, and emergency services.",
    disclaimer: "I am an AI, not a medical professional. During waterborne disease outbreaks, follow official health authority guidance immediately."
  }
};

function findBestMatch(message: string) {
  const lower = message.toLowerCase();
  
  const keywordMap: Record<string, string[]> = {
    "clean water access": ["clean water", "water access", "safe water", "drinking water", "water supply", "water for all", "water everywhere"],
    "water contamination": ["contamination", "contaminated", "polluted", "pollution", "chemical", "toxic", "industrial"],
    "waterborne disease": ["disease", "diarrhea", "cholera", "sick", "illness", "symptoms", "fever", "vomiting", "waterborne"],
    "waterborne disease outbreak": ["outbreak", "epidemic", "multiple people sick", "community illness"],
    "water filtration": ["filter", "filtration", "purify", "purification", "boil", "treat", "clean water at home"],
    "water conservation": ["conserve", "conservation", "save water", "scarcity", "shortage", "drought", "waste water"],
    "sanitation": ["sanitation", "toilet", "sewage", "waste", "hygiene", "open defecation", "sewer"],
    "flood": ["flood", "flooding", "heavy rain", "overflow", "water damage", "storm"],
    "drought": ["drought", "dry", "no rain", "water shortage", "dry season", "lack of water"],
    "industrial pollution": ["industrial", "factory", "mining", "chemical spill", "oil", "toxic waste", "discharge"],
    "agricultural water": ["agriculture", "farming", "irrigation", "crop", "pesticide", "fertilizer", "runoff"],
    "plastic pollution": ["plastic", "microplastic", "waste", "litter", "ocean plastic", "single-use"],
    "water rights": ["water rights", "equitable", "fair access", "privatization", "human right", "discrimination"],
    "water infrastructure": ["infrastructure", "pipes", "pipeline", "treatment plant", "water system", "leak"],
    "water testing": ["test", "testing", "water quality", "check water", "safe to drink"],
    "rainwater harvesting": ["rainwater", "rain water", "harvest", "collect rain", "storage tank"],
    "groundwater": ["groundwater", "well", "borewell", "underground water", "aquifer"]
  };
  
  for (const [key, keywords] of Object.entries(keywordMap)) {
    if (keywords.some(kw => lower.includes(kw))) {
      return problemSolutions[key];
    }
  }
  
  return genericWaterResponse;
}

export function handleWaterQuery(message: string, symptoms?: string) {
  const lowerMessage = message.toLowerCase() + (symptoms ? " " + symptoms.toLowerCase() : "");
  
  const seriousSymptoms = ['diarrhea', 'vomiting', 'fever', 'dehydration', 'child', 'sick', 'blood'];
  const hasSeriousSymptoms = seriousSymptoms.some(s => lowerMessage.includes(s));

  const isProblemQuery = lowerMessage.includes("problem") || lowerMessage.includes("solve") || 
    lowerMessage.includes("how to") || lowerMessage.includes("ensure") || lowerMessage.includes("access") ||
    lowerMessage.includes("improve") || lowerMessage.includes("prevent") || lowerMessage.includes("anywhere") ||
    lowerMessage.includes("community") || lowerMessage.includes("everywhere") || lowerMessage.includes("all") ||
    lowerMessage.includes("every");

  if (isProblemQuery) {
    return findBestMatch(message);
  }

  let matchedRecord = waterDataset[0];
  
  for (const record of waterDataset) {
    if (lowerMessage.includes(record.water_issue_category.toLowerCase())) {
      matchedRecord = record;
      break;
    }
  }

  if (hasSeriousSymptoms && matchedRecord.risk_level !== 'Emergency') {
    matchedRecord = waterDataset.find(r => r.risk_level === 'Emergency') || matchedRecord;
  }

  return {
    issue_summary: matchedRecord.water_issue_category,
    possible_cause: matchedRecord.possible_cause,
    risk_level: matchedRecord.risk_level,
    immediate_safety_steps: matchedRecord.recommended_action,
    health_risk_awareness: matchedRecord.related_health_risk,
    complaint_report_suggestion: `Priority: ${matchedRecord.complaint_priority}. ${matchedRecord.resource_link}`,
    disclaimer: "I am an AI, not a doctor. I cannot diagnose diseases or prescribe medicine." + 
                (hasSeriousSymptoms ? " PLEASE CONTACT A DOCTOR OR LOCAL HEALTH CENTER IMMEDIATELY due to serious symptoms." : "")
  };
}
