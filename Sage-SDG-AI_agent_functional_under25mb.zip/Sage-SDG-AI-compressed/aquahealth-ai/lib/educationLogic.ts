import { educationDataset } from "../data/educationDataset";

const problemSolutions: Record<string, { topic_summary: string; simple_explanation: string; learning_goal: string; recommended_activity: string; quiz_question: string; progress_metric: string; sdg_connection: string }> = {
  "water": {
    topic_summary: "Clean Water Access & Protection",
    simple_explanation: "2 billion people lack safe drinking water. Solutions: 1) Map and protect local water sources from contamination. 2) Build rainwater harvesting and storage systems. 3) Implement household water treatment (boiling, filtration, chlorination). 4) Establish community water committees for maintenance. 5) Advocate for government investment in water infrastructure. 6) Protect watersheds through reforestation and pollution control. Clean water reduces child mortality by 50% and improves school attendance by 25%.",
    learning_goal: "Understand water systems and implement community-level clean water solutions.",
    recommended_activity: "Map your local water source. Identify contamination points and propose 3 solutions. Test water quality using available kits.",
    quiz_question: "Q: What are 3 practical ways a community can ensure clean water access? A: 1) Protect water sources, 2) Implement filtration/boiling, 3) Build rainwater harvesting.",
    progress_metric: "SDG 6 Knowledge: Water Systems Mastered",
    sdg_connection: "SDG 6.1 - Universal access to safe and affordable drinking water"
  },
  "sanitation": {
    topic_summary: "Sanitation Infrastructure & Disease Prevention",
    simple_explanation: "Poor sanitation causes 432,000 diarrheal deaths yearly. Solutions: 1) Build proper toilet facilities (minimum 30m from water sources). 2) Construct sewage treatment systems. 3) Install handwashing stations with soap. 4) Implement community waste management (composting, recycling). 5) Educate about sanitation-health connections. 6) Partner with NGOs (WaterAid, UNICEF) for infrastructure funding. Every $1 invested in sanitation returns $5.50 in reduced healthcare costs.",
    learning_goal: "Connect sanitation infrastructure to public health outcomes and design improvement plans.",
    recommended_activity: "Conduct a sanitation audit of your school/community. Identify gaps and design a low-cost improvement plan.",
    quiz_question: "Q: How does poor sanitation cause waterborne diseases? A: Human waste containing pathogens contaminates drinking water sources when sewage systems are inadequate.",
    progress_metric: "SDG 6 Knowledge: Sanitation Systems Mastered",
    sdg_connection: "SDG 6.2 - Adequate and equitable sanitation and hygiene for all"
  },
  "hygiene": {
    topic_summary: "Hygiene Practices & Infection Prevention",
    simple_explanation: "Handwashing with soap reduces diarrhea by 30-48% and respiratory infections by 20%. Solutions: 1) Install handwashing stations at schools, markets, and health centers. 2) Teach proper handwashing technique (20 seconds with soap). 3) Promote safe food handling and clean water storage. 4) Implement community hygiene education campaigns. 5) Ensure access to soap and clean water in households. 6) Monitor hygiene practices through community health workers.",
    learning_goal: "Identify critical hygiene practices and implement community education programs.",
    recommended_activity: "Design a hygiene awareness campaign focusing on handwashing and safe water storage for your community.",
    quiz_question: "Q: By what percentage does handwashing with soap reduce diarrheal diseases? A: 30-48%.",
    progress_metric: "SDG 3 Knowledge: Hygiene & Prevention Mastered",
    sdg_connection: "SDG 3.3 - End epidemics of waterborne and communicable diseases"
  },
  "mental health": {
    topic_summary: "Mental Health Awareness & Support Systems",
    simple_explanation: "1 in 4 people experience mental health conditions. Solutions: 1) Build peer support networks and safe spaces for conversation. 2) Train community health workers in basic mental health first aid. 3) Reduce stigma through education and open dialogue. 4) Provide access to counseling services (in-person or telehealth). 5) Teach stress management techniques (mindfulness, breathing exercises). 6) Create school and workplace mental health policies. Early intervention prevents conditions from worsening.",
    learning_goal: "Recognize mental health challenges and build community support systems.",
    recommended_activity: "Create a personal well-being plan including stress management techniques, support contacts, and daily self-care practices.",
    quiz_question: "Q: Name 3 evidence-based strategies for managing stress. A: 1) Regular physical activity, 2) Mindfulness/meditation, 3) Maintaining social connections.",
    progress_metric: "SDG 3 Knowledge: Mental Health Awareness Mastered",
    sdg_connection: "SDG 3.4 - Promote mental health and well-being"
  },
  "nutrition": {
    topic_summary: "Nutrition Security & Healthy Diets",
    simple_explanation: "Malnutrition affects 1 in 3 people globally. Solutions: 1) Promote diverse diets using locally available foods. 2) Implement school meal programs to improve attendance and learning. 3) Fortify staple foods with essential vitamins and minerals. 4) Educate about infant and young child feeding practices. 5) Support home gardens and small-scale agriculture. 6) Ensure clean water access (contaminated water prevents nutrient absorption). 7) Screen for malnutrition in community health programs.",
    learning_goal: "Understand nutrition-water-health connections and design community nutrition programs.",
    recommended_activity: "Analyze a typical daily meal plan. Identify nutritional gaps and propose improvements using locally available foods.",
    quiz_question: "Q: How does contaminated water affect nutrition? A: It causes diarrheal diseases that prevent nutrient absorption, leading to malnutrition especially in children.",
    progress_metric: "SDG 2 & 3 Knowledge: Nutrition Mastered",
    sdg_connection: "SDG 2.2 - End all forms of malnutrition"
  },
  "education access": {
    topic_summary: "Equal Access to Quality Education",
    simple_explanation: "244 million children are out of school globally. Solutions: 1) Eliminate school fees and provide free primary/secondary education. 2) Implement school meal programs to attract attendance. 3) Train and deploy qualified teachers to underserved areas. 4) Build schools within safe walking distance. 5) Provide digital learning tools and internet access. 6) Ensure girls' education through scholarships and safe facilities. 7) Adapt schools for children with disabilities. Each additional year of schooling increases earnings by 10%.",
    learning_goal: "Identify education barriers and design inclusive access programs.",
    recommended_activity: "Research education access challenges in your community. Design a program to help 5 out-of-school children enroll.",
    quiz_question: "Q: How does each additional year of schooling affect future earnings? A: It increases earnings by approximately 10%.",
    progress_metric: "SDG 4 Knowledge: Education Access Mastered",
    sdg_connection: "SDG 4.1 - Free, equitable, and quality primary and secondary education"
  },
  "climate": {
    topic_summary: "Climate Action & Environmental Protection",
    simple_explanation: "Climate change threatens water, food, and health. Solutions: 1) Transition to renewable energy (solar, wind, hydro). 2) Protect and restore forests (carbon sinks). 3) Implement water conservation and efficient irrigation. 4) Promote sustainable agriculture practices. 5) Reduce waste through recycling and composting. 6) Advocate for climate policies and carbon pricing. 7) Build climate-resilient infrastructure. Individual actions: reduce consumption, conserve water, use clean energy, and support sustainable businesses.",
    learning_goal: "Connect climate action to water, health, and education outcomes.",
    recommended_activity: "Calculate your carbon and water footprint. Create a personal action plan to reduce both by 20%.",
    quiz_question: "Q: Name 3 renewable energy sources that reduce climate impact. A: Solar, Wind, and Hydroelectric power.",
    progress_metric: "SDG 13 Knowledge: Climate Action Mastered",
    sdg_connection: "SDG 13.3 - Climate change education and awareness"
  },
  "digital literacy": {
    topic_summary: "Digital Literacy & Technology Access",
    simple_explanation: "2.6 billion people lack internet access, creating a digital divide. Solutions: 1) Provide affordable internet and devices to underserved communities. 2) Teach basic digital skills (typing, browsing, online safety). 3) Integrate technology into school curricula. 4) Create community digital learning centers. 5) Train teachers in digital pedagogy. 6) Develop offline learning resources for areas without connectivity. 7) Teach critical thinking to combat misinformation. Digital literacy is essential for modern employment and education.",
    learning_goal: "Bridge the digital divide through access, skills training, and safe online practices.",
    recommended_activity: "Teach 3 basic digital skills to someone in your community who lacks access. Document their progress.",
    quiz_question: "Q: Why is digital literacy critical for education and employment? A: It enables access to online learning, job opportunities, communication, and essential services in the modern economy.",
    progress_metric: "SDG 4 & 9 Knowledge: Digital Literacy Mastered",
    sdg_connection: "SDG 4.4 - Increase ICT skills for employment and entrepreneurship"
  },
  "girls education": {
    topic_summary: "Girls' Education & Gender Equality",
    simple_explanation: "129 million girls are out of school globally. Barriers include child marriage, poverty, safety concerns, and cultural norms. Solutions: 1) Eliminate school fees and provide scholarships for girls. 2) Build separate toilet facilities for girls. 3) Provide menstrual hygiene management supplies and education. 4) Ensure safe transportation to school. 5) Engage parents and community leaders to value girls' education. 6) Train female teachers as role models. Educating girls reduces child marriage by 50% and increases future earnings by 15-25%.",
    learning_goal: "Identify barriers to girls' education and design gender-inclusive programs.",
    recommended_activity: "Research barriers to girls' education in your community. Propose 3 actionable solutions to increase enrollment and retention.",
    quiz_question: "Q: How does educating girls impact community development? A: It reduces child marriage, improves child health, increases family income, and breaks poverty cycles across generations.",
    progress_metric: "SDG 4 & 5 Knowledge: Gender Equality in Education Mastered",
    sdg_connection: "SDG 4.5 - Eliminate gender disparities in education"
  },
  "poverty": {
    topic_summary: "Poverty Reduction & Economic Empowerment",
    simple_explanation: "700 million people live in extreme poverty (<$2.15/day). Solutions: 1) Provide quality education and vocational training. 2) Support microfinance and small business development. 3) Ensure access to healthcare and social protection. 4) Create decent work opportunities with fair wages. 5) Invest in infrastructure (roads, electricity, internet). 6) Promote financial literacy and savings programs. 7) Support agricultural productivity for rural communities. Education is the most powerful tool to break poverty cycles.",
    learning_goal: "Understand poverty drivers and design multi-sectoral empowerment programs.",
    recommended_activity: "Map poverty indicators in your community. Design a program combining education, skills training, and microfinance to lift 10 families out of poverty.",
    quiz_question: "Q: What is the most effective long-term strategy for poverty reduction? A: Quality education combined with skills training and access to economic opportunities.",
    progress_metric: "SDG 1 Knowledge: Poverty Reduction Mastered",
    sdg_connection: "SDG 1.1 - Eradicate extreme poverty for all people everywhere"
  },
  "disability inclusion": {
    topic_summary: "Disability Inclusion in Education & Community",
    simple_explanation: "Children with disabilities are 2-3 times more likely to be out of school. Solutions: 1) Build accessible school infrastructure (ramps, accessible toilets). 2) Train teachers in inclusive education methods. 3) Provide assistive devices (wheelchairs, hearing aids, Braille materials). 4) Adapt curricula for different learning needs. 5) Combat stigma through community awareness campaigns. 6) Ensure accessible transportation to schools. 7) Involve persons with disabilities in policy design. Inclusive education benefits ALL students.",
    learning_goal: "Design inclusive education and community programs that leave no one behind.",
    recommended_activity: "Audit a local school or community space for accessibility barriers. Propose 5 improvements for disability inclusion.",
    quiz_question: "Q: Why is inclusive education beneficial for all students, not just those with disabilities? A: It teaches empathy, diversity appreciation, and creates learning environments that adapt to different needs and learning styles.",
    progress_metric: "SDG 4 & 10 Knowledge: Disability Inclusion Mastered",
    sdg_connection: "SDG 4.5 - Ensure equal access to all levels of education for persons with disabilities"
  },
  "early childhood": {
    topic_summary: "Early Childhood Development & Education",
    simple_explanation: "Half of children worldwide lack access to early learning. The first 5 years are critical for brain development. Solutions: 1) Expand access to quality preschool and childcare. 2) Train early childhood educators. 3) Provide parenting education on nutrition, stimulation, and responsive caregiving. 4) Create safe play and learning spaces. 5) Screen for developmental delays early. 6) Support maternal health and nutrition during pregnancy. 7) Integrate early learning with health and nutrition services. Every $1 invested in early childhood returns $7-10 in adulthood.",
    learning_goal: "Understand the critical importance of early childhood development and design support programs.",
    recommended_activity: "Design an early learning activity for children aged 3-5 using locally available materials. Explain how it supports cognitive, physical, and social development.",
    quiz_question: "Q: Why are the first 5 years of life critical for development? A: 80% of brain development occurs by age 3, and early experiences shape learning capacity, health, and behavior throughout life.",
    progress_metric: "SDG 4.2 Knowledge: Early Childhood Development Mastered",
    sdg_connection: "SDG 4.2 - Quality early childhood development, care and pre-primary education"
  },
  "teacher training": {
    topic_summary: "Teacher Training & Education Quality",
    simple_explanation: "69 million new teachers are needed globally to achieve universal education by 2030. Solutions: 1) Invest in pre-service and in-service teacher training. 2) Provide ongoing professional development and mentoring. 3) Improve teacher working conditions and salaries. 4) Deploy teachers to underserved areas with incentives. 5) Integrate technology and modern pedagogy into training. 6) Support teacher well-being to prevent burnout. 7) Establish peer learning communities. Teacher quality is the single most important school factor affecting student achievement.",
    learning_goal: "Identify teacher training needs and design professional development programs.",
    recommended_activity: "Observe a classroom or interview a teacher. Identify 3 areas where additional training or support would improve student learning outcomes.",
    quiz_question: "Q: What is the single most important school factor affecting student achievement? A: Teacher quality and effectiveness.",
    progress_metric: "SDG 4.c Knowledge: Teacher Training Mastered",
    sdg_connection: "SDG 4.c - Increase supply of qualified teachers"
  },
  "healthcare access": {
    topic_summary: "Universal Healthcare Access & Primary Care",
    simple_explanation: "Half the world lacks access to essential health services. Solutions: 1) Strengthen primary healthcare systems at community level. 2) Train and deploy community health workers. 3) Provide essential medicines and vaccines. 4) Remove financial barriers (universal health coverage). 5) Build health facilities within reach of all communities. 6) Integrate mental health into primary care. 7) Use telemedicine for remote areas. 8) Ensure clean water and sanitation in health facilities. Healthcare access is a fundamental human right.",
    learning_goal: "Understand healthcare system barriers and design community-level health access programs.",
    recommended_activity: "Map healthcare facilities in your area. Identify gaps in access and propose solutions for the most underserved population.",
    quiz_question: "Q: What is the most effective level of healthcare delivery for reaching underserved populations? A: Primary healthcare delivered by trained community health workers at the local level.",
    progress_metric: "SDG 3 Knowledge: Healthcare Access Mastered",
    sdg_connection: "SDG 3.8 - Universal health coverage and access to quality essential health services"
  },
  "maternal health": {
    topic_summary: "Maternal & Newborn Health Protection",
    simple_explanation: "287,000 women died from pregnancy-related causes in 2020. Solutions: 1) Ensure skilled birth attendants at every delivery. 2) Provide prenatal and postnatal care visits. 3) Ensure access to emergency obstetric care. 4) Provide family planning services and education. 5) Educate about danger signs during pregnancy. 6) Improve nutrition for pregnant and breastfeeding women. 7) Ensure clean water and sanitation in maternity facilities. 8) Support maternal mental health. Most maternal deaths are preventable with proper care.",
    learning_goal: "Identify maternal health risks and design comprehensive care programs.",
    recommended_activity: "Research maternal health indicators in your community. Design a program to improve prenatal care access and skilled birth attendance.",
    quiz_question: "Q: What percentage of maternal deaths are preventable with proper healthcare? A: The vast majority - most maternal deaths can be prevented with skilled birth attendance and emergency obstetric care.",
    progress_metric: "SDG 3.1 Knowledge: Maternal Health Mastered",
    sdg_connection: "SDG 3.1 - Reduce global maternal mortality ratio"
  },
  "disease prevention": {
    topic_summary: "Infectious Disease Prevention & Control",
    simple_explanation: "Infectious diseases kill millions annually. Solutions: 1) Ensure vaccination coverage for all children. 2) Improve water, sanitation, and hygiene (WASH). 3) Strengthen disease surveillance and early warning systems. 4) Provide vector control (mosquito nets, spraying). 5) Promote safe sex education and HIV prevention. 6) Ensure access to antibiotics and antiviral treatments. 7) Combat antimicrobial resistance through proper antibiotic use. 8) Build community health education programs. Prevention is far more effective and cost-efficient than treatment.",
    learning_goal: "Design comprehensive disease prevention strategies for communities.",
    recommended_activity: "Research the top 3 infectious diseases in your area. Design a prevention campaign targeting the most prevalent one.",
    quiz_question: "Q: What is the most cost-effective health intervention globally? A: Vaccination - it prevents millions of deaths annually and costs far less than treating diseases.",
    progress_metric: "SDG 3.3 Knowledge: Disease Prevention Mastered",
    sdg_connection: "SDG 3.3 - End epidemics of AIDS, tuberculosis, malaria, and waterborne diseases"
  },
  "food security": {
    topic_summary: "Food Security & Sustainable Agriculture",
    simple_explanation: "828 million people face hunger globally. Solutions: 1) Support smallholder farmers with training, seeds, and credit. 2) Promote sustainable farming (crop rotation, organic methods). 3) Reduce food waste (30% of food is lost or wasted). 4) Build resilient food systems against climate shocks. 5) Improve storage and distribution infrastructure. 6) Support school feeding programs. 7) Promote home gardens and urban agriculture. 8) Ensure access to clean water for irrigation. Food security requires availability, access, utilization, and stability.",
    learning_goal: "Understand food system challenges and design community food security programs.",
    recommended_activity: "Assess food security in your community. Design a program combining home gardens, nutrition education, and food waste reduction.",
    quiz_question: "Q: What percentage of food produced globally is lost or wasted? A: Approximately 30% - reducing waste is one of the most effective ways to improve food security.",
    progress_metric: "SDG 2 Knowledge: Food Security Mastered",
    sdg_connection: "SDG 2.1 - End hunger and ensure access to safe and nutritious food"
  },
  "gender equality": {
    topic_summary: "Gender Equality & Women's Empowerment",
    simple_explanation: "Gender inequality persists in education, work, health, and leadership. Solutions: 1) Ensure equal access to education for girls and boys. 2) Eliminate gender-based violence through education and legal protection. 3) Promote women's economic empowerment (equal pay, land rights, credit). 4) Increase women's representation in leadership and decision-making. 5) Engage men and boys as allies. 6) Provide reproductive health services and education. 7) Challenge harmful cultural norms and stereotypes. Gender equality accelerates progress on ALL SDGs.",
    learning_goal: "Identify gender inequality drivers and design empowerment programs.",
    recommended_activity: "Research gender disparities in your community. Design a program addressing the most critical gap (education, economic, or leadership).",
    quiz_question: "Q: How does gender equality impact overall development? A: It accelerates progress on all SDGs - educated, empowered women invest in their families, communities, and economies.",
    progress_metric: "SDG 5 Knowledge: Gender Equality Mastered",
    sdg_connection: "SDG 5.1 - End all forms of discrimination against women and girls"
  },
  "youth unemployment": {
    topic_summary: "Youth Employment & Skills Development",
    simple_explanation: "73 million young people are unemployed globally. Solutions: 1) Align education with labor market needs. 2) Provide vocational training and apprenticeships. 3) Support youth entrepreneurship (training, mentoring, startup funding). 4) Develop digital and green economy skills. 5) Create internship and work experience programs. 6) Remove barriers to youth employment (transport, childcare). 7) Promote decent work with fair wages and safe conditions. 8) Support transition from school to work. Youth employment drives economic growth and social stability.",
    learning_goal: "Design youth employment programs combining education, skills, and economic opportunities.",
    recommended_activity: "Research youth employment challenges in your area. Design a skills training program aligned with local job market needs.",
    quiz_question: "Q: What is the most effective approach to reducing youth unemployment? A: Combining relevant skills training with work experience and entrepreneurship support.",
    progress_metric: "SDG 8 Knowledge: Youth Employment Mastered",
    sdg_connection: "SDG 8.6 - Reduce proportion of youth not in employment, education or training"
  },
  "clean energy": {
    topic_summary: "Affordable & Clean Energy (SDG 7)",
    simple_explanation: "759 million people lack electricity access. Solutions: 1) Expand renewable energy (solar, wind, hydro, geothermal). 2) Improve energy efficiency in buildings and industry. 3) Provide off-grid solar solutions for remote areas. 4) Invest in energy storage technology. 5) Phase out fossil fuel subsidies. 6) Promote clean cooking solutions (3 billion people use polluting fuels). 7) Support international cooperation for clean energy technology transfer. Clean energy is central to achieving most SDGs.",
    learning_goal: "Understand energy systems and design community-level clean energy solutions.",
    recommended_activity: "Assess energy access in your community. Design a plan to introduce solar or other renewable energy for households without reliable electricity.",
    quiz_question: "Q: How many people globally lack access to electricity? A: Approximately 759 million people, mostly in sub-Saharan Africa and South Asia.",
    progress_metric: "SDG 7 Knowledge: Clean Energy Mastered",
    sdg_connection: "SDG 7.1 - Universal access to affordable, reliable, and modern energy services"
  },
  "economic growth": {
    topic_summary: "Decent Work & Economic Growth (SDG 8)",
    simple_explanation: "Global GDP per capita grew 50% since 2000, but progress is uneven. Solutions: 1) Promote full and productive employment for all. 2) Eradicate forced labor, slavery, and human trafficking. 3) Protect labor rights and promote safe working environments. 4) Support small and medium enterprises. 5) Decouple economic growth from environmental degradation. 6) Promote sustainable tourism. 7) Strengthen domestic financial institutions. Economic growth must be inclusive and sustainable.",
    learning_goal: "Design economic development programs that create decent work while protecting the environment.",
    recommended_activity: "Map local businesses and employment opportunities. Identify gaps and propose a program to support small enterprise development.",
    quiz_question: "Q: What does 'decoupling economic growth from environmental degradation' mean? A: Growing the economy without increasing pressure on environmental resources - doing more with less.",
    progress_metric: "SDG 8 Knowledge: Economic Growth Mastered",
    sdg_connection: "SDG 8.1 - Sustain per capita economic growth"
  },
  "reduced inequalities": {
    topic_summary: "Reduced Inequalities (SDG 10)",
    simple_explanation: "Income inequality has increased in most regions. The richest 10% earn up to 40% of global income. Solutions: 1) Implement progressive fiscal policies. 2) Ensure equal opportunity and reduce inequalities of outcome. 3) Eliminate discriminatory laws and practices. 4) Facilitate orderly, safe migration and mobility. 5) Improve regulation of global financial markets. 6) Enhance developing countries' voice in global decision-making. 7) Reduce transaction costs for migrant remittances. Inequality threatens social cohesion and economic progress.",
    learning_goal: "Identify inequality drivers and design policies for inclusive development.",
    recommended_activity: "Research inequality indicators in your community. Propose 3 policies to reduce gaps in opportunity or outcome.",
    quiz_question: "Q: What percentage of global income does the richest 10% earn? A: Up to 40% of global income, while the poorest 10% earn only 2-7%.",
    progress_metric: "SDG 10 Knowledge: Reduced Inequalities Mastered",
    sdg_connection: "SDG 10.1 - Progressively achieve and sustain income growth of the bottom 40%"
  },
  "sustainable cities": {
    topic_summary: "Sustainable Cities & Communities (SDG 11)",
    simple_explanation: "55% of the world's population lives in urban areas, projected to reach 68% by 2050. Solutions: 1) Ensure access to adequate, safe, and affordable housing. 2) Provide access to safe, affordable, accessible transport systems. 3) Enhance inclusive and sustainable urbanization. 4) Protect cultural and natural heritage. 5) Reduce adverse environmental impact of cities (air quality, waste management). 6) Provide universal access to safe, inclusive green and public spaces. 7) Build resilience to disasters.",
    learning_goal: "Design sustainable urban development solutions for growing cities.",
    recommended_activity: "Assess your city's sustainability. Identify 3 areas for improvement (housing, transport, green spaces, waste management) and propose solutions.",
    quiz_question: "Q: What percentage of the world's population lives in urban areas? A: 55%, projected to reach 68% by 2050.",
    progress_metric: "SDG 11 Knowledge: Sustainable Cities Mastered",
    sdg_connection: "SDG 11.1 - Access to adequate, safe, and affordable housing"
  },
  "responsible consumption": {
    topic_summary: "Responsible Consumption & Production (SDG 12)",
    simple_explanation: "If global population reaches 9.6 billion by 2050, we'll need 3 planets to sustain current consumption patterns. Solutions: 1) Reduce food waste by 50% at retail and consumer levels. 2) Achieve environmentally sound management of chemicals and waste. 3) Reduce waste generation through prevention, reduction, recycling, and reuse. 4) Encourage companies to adopt sustainable practices. 5) Promote sustainable public procurement. 6) Ensure people have information for sustainable development. 7) Phase out inefficient fossil fuel subsidies.",
    learning_goal: "Design waste reduction and sustainable consumption programs.",
    recommended_activity: "Conduct a personal or household waste audit. Create a plan to reduce waste by 30% through reduction, reuse, and recycling.",
    quiz_question: "Q: How many planets would we need if everyone consumed at current levels by 2050? A: Approximately 3 planets - we must change consumption patterns.",
    progress_metric: "SDG 12 Knowledge: Responsible Consumption Mastered",
    sdg_connection: "SDG 12.3 - Halve per capita global food waste"
  },
  "life below water": {
    topic_summary: "Life Below Water (SDG 14)",
    simple_explanation: "Oceans cover 71% of Earth and absorb 30% of CO2 produced by humans. Solutions: 1) Prevent and reduce marine pollution (plastics, nutrients, chemicals). 2) Sustainably manage and protect marine and coastal ecosystems. 3) Minimize and address ocean acidification. 4) End overfishing and implement science-based management. 5) Conserve at least 10% of coastal and marine areas. 6) End subsidies that contribute to overfishing. 7) Increase scientific knowledge and marine technology. Ocean health is critical for climate regulation and food security.",
    learning_goal: "Understand marine ecosystems and design ocean conservation strategies.",
    recommended_activity: "Research threats to local water bodies (rivers, lakes, coasts). Design a community action plan to reduce pollution and protect aquatic life.",
    quiz_question: "Q: What percentage of Earth's surface is covered by oceans? A: 71% - oceans are essential for climate regulation, food, and oxygen.",
    progress_metric: "SDG 14 Knowledge: Life Below Water Mastered",
    sdg_connection: "SDG 14.1 - Prevent and significantly reduce marine pollution"
  },
  "life on land": {
    topic_summary: "Life on Land (SDG 15)",
    simple_explanation: "Forests cover 31% of land area but are being lost at 10 million hectares per year. Solutions: 1) Combat desertification and restore degraded land. 2) Halt biodiversity loss and protect endangered species. 3) Integrate ecosystem values into planning. 4) Mobilize financial resources for sustainable forest management. 5) End poaching and trafficking of protected species. 6) Prevent introduction of invasive alien species. 7) Support local communities in conservation efforts. Terrestrial ecosystems provide food, water, and climate regulation.",
    learning_goal: "Design biodiversity conservation and land restoration programs.",
    recommended_activity: "Map local ecosystems and identify threats. Design a restoration or conservation project for a degraded area in your community.",
    quiz_question: "Q: How much forest area is lost annually? A: Approximately 10 million hectares per year - equivalent to the size of Iceland.",
    progress_metric: "SDG 15 Knowledge: Life on Land Mastered",
    sdg_connection: "SDG 15.1 - Conserve and restore terrestrial and freshwater ecosystems"
  },
  "peace and justice": {
    topic_summary: "Peace, Justice & Strong Institutions (SDG 16)",
    simple_explanation: "Conflict, corruption, and weak institutions undermine development. Solutions: 1) Reduce all forms of violence and related death rates. 2) End abuse, exploitation, trafficking, and violence against children. 3) Promote rule of law and equal access to justice. 4) Reduce illicit financial and arms flows. 5) Substantially reduce corruption and bribery. 6) Develop effective, accountable, and transparent institutions. 7) Ensure responsive, inclusive, participatory decision-making. 8) Provide legal identity for all. Peace is foundational for all other SDGs.",
    learning_goal: "Understand the role of institutions in development and design governance improvement strategies.",
    recommended_activity: "Research governance indicators in your country. Identify 3 areas for institutional improvement and propose citizen-led solutions.",
    quiz_question: "Q: Why is SDG 16 (Peace and Justice) considered foundational for all other SDGs? A: Without peace, justice, and strong institutions, progress on health, education, poverty, and other goals is severely undermined.",
    progress_metric: "SDG 16 Knowledge: Peace & Justice Mastered",
    sdg_connection: "SDG 16.1 - Significantly reduce all forms of violence"
  },
  "partnerships": {
    topic_summary: "Partnerships for the Goals (SDG 17)",
    simple_explanation: "Achieving the SDGs requires $5-7 trillion annually, but developing countries face a $2.5 trillion financing gap. Solutions: 1) Strengthen domestic resource mobilization (tax collection). 2) Developed countries should meet 0.7% ODA/GNI target. 3) Mobilize additional financial resources from multiple sources. 4) Assist developing countries in debt sustainability. 5) Adopt investment promotion regimes for least developed countries. 6) Enhance North-South, South-South, and triangular cooperation. 7) Promote development of multi-stakeholder partnerships. No single actor can achieve the SDGs alone.",
    learning_goal: "Design multi-stakeholder partnerships to advance SDG implementation.",
    recommended_activity: "Map potential partners (government, NGOs, businesses, academia) for an SDG project in your community. Design a partnership framework.",
    quiz_question: "Q: What is the annual SDG financing gap for developing countries? A: Approximately $2.5 trillion - partnerships are essential to close this gap.",
    progress_metric: "SDG 17 Knowledge: Partnerships Mastered",
    sdg_connection: "SDG 17.17 - Encourage and promote effective public, public-private, and civil society partnerships"
  },
  "no poverty": {
    topic_summary: "No Poverty (SDG 1)",
    simple_explanation: "700 million people live in extreme poverty (<$2.15/day). Solutions: 1) Implement social protection systems for all. 2) Ensure equal rights to economic resources and basic services. 3) Build resilience of the poor to climate and other shocks. 4) Mobilize resources from development cooperation. 5) Create pro-poor and gender-sensitive development policies. 6) Promote sustained, inclusive economic growth. 7) Ensure significant mobilization of resources. Poverty is not just about income - it includes lack of education, health, and voice.",
    learning_goal: "Design comprehensive poverty reduction programs addressing multiple dimensions.",
    recommended_activity: "Research poverty indicators in your community. Design a program combining income support, education access, and healthcare for vulnerable families.",
    quiz_question: "Q: What is the international poverty line? A: $2.15 per day (2017 PPP) - but poverty includes more than income: education, health, living standards, and voice.",
    progress_metric: "SDG 1 Knowledge: No Poverty Mastered",
    sdg_connection: "SDG 1.1 - Eradicate extreme poverty for all people everywhere"
  },
  "zero hunger": {
    topic_summary: "Zero Hunger (SDG 2)",
    simple_explanation: "828 million people face hunger globally. Solutions: 1) End hunger and ensure access to safe, nutritious food. 2) End all forms of malnutrition. 3) Double agricultural productivity and incomes of small-scale food producers. 4) Ensure sustainable food production systems and resilient agricultural practices. 5) Maintain genetic diversity of seeds and plants. 6) Correct and prevent trade restrictions and distortions in world agricultural markets. 7) Ensure proper functioning of food commodity markets. Hunger is solvable - we produce enough food for everyone.",
    learning_goal: "Design food security programs addressing availability, access, utilization, and stability.",
    recommended_activity: "Assess food security in your community. Design a program combining local food production, nutrition education, and waste reduction.",
    quiz_question: "Q: How many people face hunger globally? A: 828 million - despite producing enough food for all, distribution and access remain challenges.",
    progress_metric: "SDG 2 Knowledge: Zero Hunger Mastered",
    sdg_connection: "SDG 2.1 - End hunger and ensure access to safe and nutritious food"
  },
  "good health": {
    topic_summary: "Good Health & Well-Being (SDG 3)",
    simple_explanation: "Universal health coverage remains out of reach for billions. Solutions: 1) Reduce maternal mortality to <70 per 100,000 live births. 2) End preventable deaths of newborns and children under 5. 3) End epidemics of AIDS, tuberculosis, malaria, and waterborne diseases. 4) Reduce premature mortality from non-communicable diseases. 5) Strengthen prevention and treatment of substance abuse. 6) Halve deaths and injuries from road traffic accidents. 7) Ensure universal access to sexual and reproductive healthcare. 8) Achieve universal health coverage.",
    learning_goal: "Design comprehensive health programs addressing prevention, treatment, and universal coverage.",
    recommended_activity: "Map health services in your area. Identify gaps and propose a community health program targeting the most underserved population.",
    quiz_question: "Q: What does universal health coverage mean? A: All people have access to quality health services they need, when and where they need them, without financial hardship.",
    progress_metric: "SDG 3 Knowledge: Good Health Mastered",
    sdg_connection: "SDG 3.8 - Achieve universal health coverage"
  },
  "quality education": {
    topic_summary: "Quality Education (SDG 4)",
    simple_explanation: "244 million children and youth are out of school. Solutions: 1) Ensure free, equitable, and quality primary and secondary education. 2) Ensure access to quality early childhood development and pre-primary education. 3) Ensure equal access to affordable technical, vocational, and higher education. 4) Increase the number of qualified teachers. 5) Build and upgrade education facilities that are child, disability, and gender sensitive. 6) Ensure all youth and adults achieve literacy and numeracy. 7) Ensure all learners acquire knowledge and skills for sustainable development.",
    learning_goal: "Design inclusive education programs that leave no one behind.",
    recommended_activity: "Research education access challenges in your community. Design a program to help out-of-school children enroll and stay in school.",
    quiz_question: "Q: How many children and youth are out of school globally? A: 244 million - barriers include poverty, conflict, gender discrimination, and lack of infrastructure.",
    progress_metric: "SDG 4 Knowledge: Quality Education Mastered",
    sdg_connection: "SDG 4.1 - Free, equitable, and quality primary and secondary education"
  }
};

const genericEducationResponse = {
  topic_summary: "General SDG Learning Support",
  simple_explanation: "The Sustainable Development Goals (SDGs) are 17 interconnected global goals adopted by all UN Member States in 2015. They address global challenges including poverty, inequality, climate change, environmental degradation, peace, and justice. Each goal has specific targets to be achieved by 2030. The SDGs recognize that action in one area affects outcomes in others, and that development must balance social, economic, and environmental sustainability.",
  learning_goal: "Understand how the SDGs connect to each other and identify actionable steps you can take in your community.",
  recommended_activity: "Choose one SDG that matters most to you. Research its targets, identify local organizations working on it, and find one action you can take this week to contribute.",
  quiz_question: "Q: How many Sustainable Development Goals are there and what is their target year? A: There are 17 SDGs with a target achievement year of 2030.",
  progress_metric: "SDG Knowledge: General Awareness Built",
  sdg_connection: "All 17 SDGs - Interconnected goals for a better world by 2030"
};

function findBestMatch(message: string) {
  const lower = message.toLowerCase();
  
  const keywordMap: Record<string, string[]> = {
    "water": ["water", "drink", "clean water", "water supply", "water access", "water quality", "safe water", "drinking water", "sdg 6"],
    "sanitation": ["sanitation", "toilet", "sewage", "waste", "sewer", "latrine", "open defecation", "waste management"],
    "hygiene": ["hygiene", "handwash", "hand wash", "soap", "washing", "germ", "infection prevention"],
    "mental health": ["mental", "stress", "anxiety", "depression", "sad", "overwhelm", "wellbeing", "well-being", "mind", "emotional", "psychological"],
    "nutrition": ["nutrition", "food", "diet", "hungry", "malnutrition", "hunger", "meal", "eat", "famine"],
    "education access": ["education", "school", "learn", "teach", "student", "teacher", "literacy", "out of school", "access to education"],
    "climate": ["climate", "environment", "pollution", "renewable", "carbon", "global warming", "sustainable", "deforestation"],
    "digital literacy": ["digital", "technology", "internet", "computer", "online", "digital divide", "tech"],
    "girls education": ["girl", "girls", "gender", "women", "female education", "child marriage"],
    "poverty": ["poverty", "poor", "income", "economic", "wealth", "inequality", "homeless"],
    "disability inclusion": ["disability", "disabled", "accessible", "inclusion", "inclusive", "special needs"],
    "early childhood": ["early childhood", "preschool", "young children", "toddler", "infant", "baby", "early learning"],
    "teacher training": ["teacher", "training", "educator", "professional development", "teaching quality"],
    "healthcare access": ["healthcare", "health care", "hospital", "clinic", "doctor", "medical", "treatment", "medicine"],
    "maternal health": ["maternal", "pregnancy", "pregnant", "mother", "newborn", "birth", "delivery", "midwife"],
    "disease prevention": ["disease", "vaccine", "vaccination", "epidemic", "outbreak", "infectious", "malaria", "hiv", "tuberculosis"],
    "food security": ["food security", "hunger", "famine", "agriculture", "farming", "crop", "food waste"],
    "gender equality": ["gender equality", "women empowerment", "discrimination", "equal rights", "women rights"],
    "youth unemployment": ["unemployment", "jobs", "youth employment", "skills", "vocational", "entrepreneurship", "career"],
    "clean energy": ["clean energy", "renewable energy", "solar", "wind", "energy access", "sdg 7"],
    "economic growth": ["economic growth", "decent work", "fair wages", "labor rights", "sdg 8"],
    "reduced inequalities": ["inequality", "equal opportunity", "social protection", "migrant rights", "sdg 10"],
    "sustainable cities": ["sustainable cities", "urban planning", "public transport", "housing", "sdg 11"],
    "responsible consumption": ["responsible consumption", "recycling", "waste reduction", "sustainable production", "sdg 12"],
    "life below water": ["ocean", "marine", "sea life", "fishing", "coral", "sdg 14"],
    "life on land": ["forest", "biodiversity", "wildlife", "deforestation", "ecosystem", "sdg 15"],
    "peace and justice": ["peace", "justice", "rule of law", "human rights", "corruption", "sdg 16"],
    "partnerships": ["partnerships", "global cooperation", "international aid", "sdg 17"],
    "no poverty": ["no poverty", "end poverty", "poverty alleviation", "sdg 1"],
    "zero hunger": ["zero hunger", "end hunger", "food access", "sdg 2"],
    "good health": ["good health", "health for all", "universal health", "sdg 3"],
    "quality education": ["quality education", "education for all", "learning", "sdg 4"],
    "clean water": ["clean water", "water for all", "water sanitation", "sdg 6"]
  };
  
  for (const [key, keywords] of Object.entries(keywordMap)) {
    if (keywords.some(kw => lower.includes(kw))) {
      return problemSolutions[key] || genericEducationResponse;
    }
  }
  
  return genericEducationResponse;
}

export function handleEducationQuery(message: string) {
  const lowerMessage = message.toLowerCase();
  let matchedRecord = educationDataset[0];

  for (const record of educationDataset) {
    if (lowerMessage.includes(record.topic.toLowerCase()) || lowerMessage.includes(record.subject.toLowerCase())) {
      matchedRecord = record;
      break;
    }
  }

  const problemMatch = findBestMatch(message);
  
  const isProblemQuery = lowerMessage.includes("problem") || lowerMessage.includes("solve") || 
    lowerMessage.includes("issue") || lowerMessage.includes("how to") || lowerMessage.includes("ensure") ||
    lowerMessage.includes("access") || lowerMessage.includes("improve") || lowerMessage.includes("challenge") ||
    lowerMessage.includes("any") || lowerMessage.includes("every") || lowerMessage.includes("all");

  if (isProblemQuery) {
    return problemMatch;
  }

  return {
    topic_summary: matchedRecord.topic,
    simple_explanation: `Here is a simple explanation for ${matchedRecord.topic} in ${matchedRecord.subject}.`,
    learning_goal: matchedRecord.learning_goal,
    recommended_activity: matchedRecord.recommended_activity,
    quiz_question: matchedRecord.quiz_question,
    progress_metric: matchedRecord.progress_metric,
    sdg_connection: matchedRecord.sdg_target
  };
}
